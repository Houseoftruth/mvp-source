var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'shinedesign',
applicationName: 'mvp-lambdafunctions',
appUid: 'S8yLX23Kcd6rcr5Gcv',
orgUid: 'kRgjJDrLtqvhG5vtGM',
deploymentUid: '960cda2a-aa6f-4dca-9d1e-0d3cc68f6c90',
serviceName: 'mvp-lambdafunctions',
stageName: 'production',
pluginVersion: '3.3.0'})
const handlerWrapperArgs = { functionName: 'mvp-lambdafunctions-production-hello', timeout: 10}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
